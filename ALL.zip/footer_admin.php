<footer id="footer">
			<div class="container">
				<ul class="copyright">
					<li>&copy; 2017 Jennifer Zhou</li>
					<li><a href="../login.php">Login</a></li>
				</ul>
			</div>
		</footer>
		<!-- Scripts -->
		    
		<!-- <script src="<?php echo $toRoot; ?>assets/js/jquery.min.js"></script> -->
			<script src="<?php echo $toRoot; ?>assets/js/skel.min.js"></script>
			<script src="<?php echo $toRoot; ?>assets/js/util.js"></script>
			<script src="<?php echo $toRoot; ?>assets/js/main.js"></script>

	</body>
</html>