<?php 
$toRoot = '../';
$currentPage = 'gallery';
include($toRoot.'_header_admin.php'); 
?>
<div class="wrapper">
    <div class="container">
        
    </div>
</div>

<?php include($toRoot."footer_admin.php");?>