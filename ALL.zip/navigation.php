<div class = "headerpageimage">
	<a href="index.php"><img src="images/header-red.png" alt="" style="width:260px;height:65px;"></a>
</div>
<nav id="nav">
	<ul>
		<li><a href="index.php" class="hidden"><img src="images/header.png" alt="" style="width:75%;height:auto;"></a></a></li>
		<li><a href="about.php">About</a>
		</li>
		<li><a href="officers.php">Officers</a></li>
		<li><a href="events.php">Events</a></li>
		<li><a href="gallery.php">Gallery</a></li>
	</ul>
</nav>